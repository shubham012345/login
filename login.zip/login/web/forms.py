from django import forms
import datetime
from django.utils.translation import ugettext_lazy as _
from django.utils import timezone
from django.core.exceptions import ValidationError
from django.forms import Form
from .models import studentForm,BookAvailable

class nameForm(forms.Form):
    first_name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'enter your first name'}),required=True,max_length=40)
    last_name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'enter your last name'}),required=True,max_length=40)
    username = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'enter your username'}),required=True,max_length=40)
    emailId = forms.CharField(widget=forms.EmailInput(attrs={'class':'form-control','placeholder':'enter your email'}),required=True,max_length=40)
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'enter password'}),required=True,max_length=40)
    conf_password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'confirm password'}),required=True,max_length=40)

    class meta():
        model=studentForm
        field=['first_name','last_name','username','emailId','password','conf_password']


    def clean_username(self):
        user=self.cleaned_data['username']
        try:
            match=studentForm.objects.get(username=user)
        except:
            return self.cleaned_data['username']
        raise forms.ValidationError("username already registered")

    def clean_emailId(self):
        email=self.cleaned_data['emailId']
        try:
            match=studentForm.objects.get(emailId=email)
        except:
            return self.cleaned_data['emailId']
        raise forms.ValidationError("email id already exist")

    def clean_conf_password(self):
        pas=self.cleaned_data['password']
        cpas=self.cleaned_data['conf_password']
        MIN_LENGTH=8
        if pas!=cpas:
            raise forms.ValidationError("password did not match")
        else:
            if len(pas)<MIN_LENGTH:
                raise forms.ValidationError("password should have atleast %d characters" %MIN_LENGTH)

def date_of_issue():
    return datetime.date.today()

class BookAvailableForm(forms.Form):
    student_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'student name'}), required=True,max_length=40)
    student_id = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'student id'}), required=True,max_length=40)
    # date_of_issue=forms.DateField()
    date_of_return = forms.DateField()
    # # date_of_issue = forms.CharField(widget=forms.DateField(required=True))
    # # date_of_return = forms.CharField(widget=forms.DateField(required=True))


    class meta():
        model = BookAvailable
        field = ['student_name', 'student_id', 'date_of_issue', 'date_of_return']

        def clean_student_id(self):
            use = self.cleaned_data['student_id']
            try:
                match = BookAvailable.objects.get(student_id=use)
            except:
                return self.cleaned_data['student_id']
            raise forms.ValidationError("This Student ID belongs to someone else"
                                        "please enter vaild student ID")


class RenewBookForm(forms.Form):
    renewal_date = forms.DateField(help_text="Enter a date between now and 4 weeks (default 3).")

    def clean_renewal_date(self):
        data = self.cleaned_data['renewal_date']

        # Check date is not in past.
        if data < datetime.date.today():
            raise ValidationError(_('Invalid date - renewal in past'))

        # Check date is in range librarian allowed to change (+4 weeks).
        if data > datetime.date.today() + datetime.timedelta(weeks=4):
            raise ValidationError(_('Invalid date - renewal more than 4 weeks ahead'))

        # Remember to always return the cleaned data.
        return data
