from django.shortcuts import render,render_to_response,Http404
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.template.loader import render_to_string
from .tokens import account_activation_token
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.core.mail import send_mail
from .forms import nameForm,BookAvailableForm,RenewBookForm
from django.core.mail import EmailMessage
from .import models
from django.shortcuts import get_object_or_404
from django.template import RequestContext
import pandas
from .import forms
from .models import studentForm,BookAvailable
from django.contrib.sites.shortcuts import get_current_site
from django.contrib import messages
from django.db.models import Q
from django.core.exceptions import ObjectDoesNotExist
from .models import Book,BookInstance,Author
from django.views import generic
import datetime
from django.urls import reverse

def index(request):
    return render(request,'web/welcome.html')


def signup(request):
    if request.method=='POST':
        form_class = nameForm
        form=form_class(request.POST)

        if form.is_valid():
            first_name=form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            username = form.cleaned_data['username']
            emailId=form.cleaned_data['emailId']
            password = "12345678"
            conf_password = "12345678"
            sign_up=studentForm.objects.create(first_name=first_name,last_name=last_name,username=username,emailId=emailId,password=password,conf_password=conf_password)
            messages.success(request,"signup from has been created")
            return HttpResponseRedirect('/mysite/signup')
    else:
        form=nameForm()
    return render(request,'web/signup.html', {'frm':form})

def login(request):
    if request.method=="POST":
        email=request.POST['email']
        passw=request.POST['pass']
        try:
            match=studentForm.objects.filter(Q(emailId__iexact=email),Q(password__iexact=passw))
            if match:
                return render(request,'web/search.html',{'re':match})
                #return HttpResponseRedirect('web/welcome.html')
            else:
                messages.error(request, "no result found")

        except ObjectDoesNotExist:
            print("invalid user")

    return render(request,'web/login.html')

def search(request):
    if request.method=="POST":
        search=request.POST['srch']
        try:
            match = studentForm.objects.filter(Q(username__iexact=search))
            print(match)
            if match:
                return render(request,'web/search.html',{'sr':match})
            else:
                messages.error(request, "no result found")

        except ObjectDoesNotExist:
            print("invalid user")


    return render(request, 'web/search.html')

def del_user(request):
    if request.method=="POST":
        search=request.POST['serch']
        try:
            match = studentForm.objects.filter(Q(username__iexact=search))
            match.delete()
            messages.success(request, "The user is deleted")

        except studentForm.DoesNotExist:
            messages.error(request, "User doesnot exist")
    return render(request, 'web/del_user.html')


def Home(request):

    num_books = Book.objects.all().count()
    num_instances = BookInstance.objects.all().count()
    # Available books (status = 'a')
    num_instances_available = BookInstance.objects.filter(status__exact='a').count()
    num_authors = Author.objects.count()  # The 'all()' is implied by default.

    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'web/catalog.html',
        context={'num_books': num_books, 'num_instances': num_instances,
                 'num_instances_available': num_instances_available, 'num_authors': num_authors},
    )


def bookSearch(request):
    if request.method=="POST":
        search=request.POST['srch']

        print(search)
        try:
            match = Book.objects.filter(Q(title__iexact=search))
            if match:
                return render(request,'web/bookSearch.html',{'sr':match})
            else:
                messages.error(request, "no result found")

        except ObjectDoesNotExist:
            print("invalid user")
    return render(request, 'web/bookSearch.html')


def AllBooks(request):
    book = Book.objects.all()
    return render(request, 'web/AllBooks.html',{'book':book})


def AllAuthors(request):
    books = Book.objects.all()
    return render(request, 'web/AllAuthors.html',{'books':books})


def book_detail(request,book_id ):
    try:
        book=Book.objects.get(id=book_id)

    except:
        raise Http404("this is wrong id")
    return render(request, 'web/book_detail.html', {'book':book})



def available(request):
    if request.method=='POST':
        print("1")
        form=BookAvailableForm(request.POST)
        print("2")
        if form.is_valid():
            student_name=form.cleaned_data['student_name']
            student_id = form.cleaned_data['student_id']
            date_of_issue = datetime.date.today()
            print(date_of_issue)
            date_of_return=form.cleaned_data['date_of_return']

            sign_up=BookAvailable.objects.create(student_name=student_name,student_id=student_id,date_of_issue=date_of_issue,date_of_return=date_of_return)
            messages.success(request,"Book is Issued")
            return HttpResponseRedirect('/mysite/available')
    else:
        form=BookAvailableForm()
    return render(request,'web/BookAvilable.html', {'frm':form})

#
def renew_book_librarian(request):
    book_inst=get_object_or_404

    # If this is a POST request then process the Form data
    if request.method == 'POST':

        # Create a form instance and populate it with data from the request (binding):
        form = RenewBookForm(request.POST)

        # Check if the form is valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required (here we just write it to the model due_back field)
            book_inst.due_back = form.cleaned_data['renewal_date']
            book_inst.save()

            # redirect to a new URL:
            return HttpResponseRedirect(reverse('all-borrowed') )

    # If this is a GET (or any other method) create the default form.
    else:
        proposed_renewal_date = datetime.date.today() + datetime.timedelta(weeks=3)
        form = RenewBookForm(initial={'renewal_date': proposed_renewal_date,})

    return render(request, 'web/book_renew_librarian.html', {'form': form, 'bookinst':book_inst})






