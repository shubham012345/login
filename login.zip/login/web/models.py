from django.db import models
import uuid
import datetime
from django.utils import timezone

from datetime import timedelta
from django.urls import reverse

# Create your models here.
class studentForm(models.Model):
    first_name=models.CharField(max_length=40)
    last_name=models.CharField(max_length=40)
    username=models.CharField(max_length=40)
    emailId=models.CharField(max_length=40)
    password=models.CharField(max_length=40)
    conf_password=models.CharField(max_length=40)

    def __str__(self):
        return self.first_name + "-" + self.last_name + "-" + self.username + "-" + self.emailId


class Author(models.Model):
    """
    Model representing an author.
    """
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100,null=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    date_of_death = models.DateField('Died', null=True, blank=True)

    def get_absolute_url(self):
        return reverse('author-detail', args=[str(self.id)])

    def __str__(self):
        return '%s, %s' % (self.first_name,self.last_name)

    # class Meta:
    #     ordering = ['first_name','last_name']


class Genre(models.Model):
    name = models.CharField(max_length=80, help_text="Enter a book genre")

    def get_absolute_url(self):
        return reverse('genre-detail', args=[str(self.id)])

    def __str__(self):
        return self.name


class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey('Author', on_delete=models.SET_NULL, null=True)
    isbn = models.CharField(max_length=40,blank=True, default='')
    genre = models.ManyToManyField(Genre, help_text='Select a genre for this book')

    def __str__(self):
        return self.title


    def get_absolute_url(self):
        """
        Returns the url to access a detail record for this book.
        """
        return reverse('book-detail', args=[str(self.id)])


class BookInstance(models.Model):
    """
    Model representing a specific copy of a book (i.e. that can be borrowed from the library).
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4,
                          help_text="Unique ID for this particular book across whole library")
    book = models.ForeignKey('Book', on_delete=models.SET_NULL, null=True)
    imprint = models.CharField(max_length=200,null=True, blank=True)
    due_back = models.DateField(null=True, blank=True)

    LOAN_STATUS = (
        ('m', 'Maintenance'),
        ('o', 'On loan'),
        ('a', 'Available'),
        ('r', 'Reserved'),
    )

    status = models.CharField(max_length=1, choices=LOAN_STATUS, blank=True, default='m', help_text='Book availability')

    class Meta:
        ordering = ["due_back"]

    def __str__(self):
        """
        String for representing the Model object
        """
        return '{0} ({1})'.format(self.id, self.book.title)


def get_deadline():
    return datetime.date.today() + timedelta(days=21)


class BookAvailable(models.Model):
    student_name=models.CharField(max_length=50)
    student_id=models.CharField(max_length=50)
    date_of_issue=models.DateField(default=datetime.date.today())
    date_of_return=models.DateField(default=get_deadline)


    def __str__(self):
        return self.student_name + "-" + self.student_id + "-" + self.date_of_issue + "-" + self.date_of_return


