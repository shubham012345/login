from django.conf.urls import include, url
from .import views


urlpatterns = [
    url(r'^signup$',views.signup,name='signup'),
    url(r'^$', views.login),
    url(r'^search/$', views.search,name='search'),
    url(r'^index$', views.index),
    url(r'^del_user$', views.del_user,name='del_user'),
    # url(r'^bookSearch$', views.bookSearch,name='bookSearch'),
    # url(r'^send_mail', views.send_mail, name='send_mail'),
    # url(r'^activate$',views.activate, name='activate'),
    # url(r'^edit_post', views.edit_post, name='edit_post'),


    url(r'^Home', views.Home, name='Home'),
    url(r'^bookSearch$', views.bookSearch,name='bookSearch'),
    url(r'^AllBooks$', views.AllBooks, name='All_Books'),
    url(r'^AllAuthors$', views.AllAuthors, name='All_Authors'),
    # url(r'AllBooks/<int:pk>', views.book_detail_view, name='book-detail'),
    url(r'^AllBooks/(?P<book_id>[0-9]+)/$', views.book_detail, name='book_detail'),
    url(r'^available$', views.available, name='available'),
    url(r'^renew_book_librarian', views.renew_book_librarian, name='renew_book_librarian'),

    # url(r'^password/$', views.change_password, name='change_password'),

]